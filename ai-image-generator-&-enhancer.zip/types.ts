
export interface InputImage {
  base64: string;
  mimeType: string;
}
